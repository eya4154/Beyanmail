BEYANNAME & TAHAKKUK ANDROID PROJESİ

Bu proje, Beyanname_Tahakkuk_Profesyonel.html dosyasını Android WebView içinde açan bir uygulama iskeletidir.
HTML dosyası app/src/main/assets/index.html içine eklenmiştir.

APK oluşturma (Android Studio):
1. Bilgisayarda Android Studio'nun güncel sürümünü kurun.
2. Bu ZIP dosyasını klasöre çıkarın.
3. Android Studio > Open ile BeyannameTahakkuk klasörünü açın.
4. Gradle senkronizasyonu tamamlanana kadar bekleyin. Gerekirse Android SDK Platform 35'i yükleyin.
5. Test APK'sı için: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.
7. Telefona kopyalayıp kurmadan önce Android ayarlarından bu kaynağa uygulama yükleme izni vermeniz gerekebilir.

ÖNEMLİ:
- Bu ortamda Android SDK/Gradle derleme araçları bulunmadığı için burada doğrudan APK derlemesi yapılamadı. Bu ZIP, Android Studio'da APK'ya derlenmek üzere hazırlanmış kaynak projedir.
- İlk açılışta ve PDF dosyası seçme, yazdırma/indirme gibi özelliklerde gerçek cihaz testi yapılmalıdır.
- HTML localStorage verileri uygulamanın WebView depolamasında tutulur. Uygulamayı kaldırmak veya uygulama verilerini temizlemek bu verileri silebilir.
- Bu uygulama sunucu tarafında kimlik doğrulaması sağlamaz. Hassas mali belgeler için cihaz güvenliği ve yedekleme ayrıca değerlendirilmelidir.
- Paket adı: com.eya.beyanname
